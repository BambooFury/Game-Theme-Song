Option Explicit

Dim shell, fso
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If WScript.Arguments.Count > 0 Then
    If LCase(WScript.Arguments(0)) = "--download" Then
        If WScript.Arguments.Count < 4 Then WScript.Quit 1
        DownloadFile WScript.Arguments(1), WScript.Arguments(2), WScript.Arguments(3)
        WScript.Quit 0
    End If

    If LCase(WScript.Arguments(0)) = "--detach" Then
        If WScript.Arguments.Count < 5 Then WScript.Quit 1
        Dim cmd, i, q
        q = Chr(34)
        cmd = q & "wscript.exe" & q & " //nologo //B " & q & WScript.ScriptFullName & q
        For i = 1 To WScript.Arguments.Count - 1
            cmd = cmd & " " & q & WScript.Arguments(i) & q
        Next
        shell.Run cmd, 0, False
        WScript.Quit 0
    End If
End If

Sub WriteFlag(path, msg)
    On Error Resume Next
    Dim f
    Set f = fso.CreateTextFile(path, True)
    f.Write msg
    f.Close
End Sub

Sub DownloadFile(url, dest, doneFlag)
    On Error Resume Next
    Dim http, stream, tmp, fileObj, size
    tmp = dest & ".part"
    If fso.FileExists(doneFlag) Then fso.DeleteFile doneFlag, True
    If fso.FileExists(tmp) Then fso.DeleteFile tmp, True
    If fso.FileExists(dest) Then fso.DeleteFile dest, True

    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    If Err.Number <> 0 Then
        Err.Clear
        Set http = CreateObject("MSXML2.ServerXMLHTTP")
    End If
    If Err.Number <> 0 Then
        WriteFlag doneFlag, "err:no_http_object:" & Err.Description
        Exit Sub
    End If

    http.setOption 2, 13056
    http.Open "GET", url, False
    http.setRequestHeader "User-Agent", "Mozilla/5.0 (game-theme-song)"
    http.setRequestHeader "Accept", "*/*"
    http.Send
    If Err.Number <> 0 Then
        WriteFlag doneFlag, "err:http_send:" & Err.Description
        Exit Sub
    End If
    If http.Status < 200 Or http.Status >= 300 Then
        WriteFlag doneFlag, "err:http_status:" & CStr(http.Status)
        Exit Sub
    End If

    Set stream = CreateObject("ADODB.Stream")
    If Err.Number <> 0 Then
        WriteFlag doneFlag, "err:no_stream:" & Err.Description
        Exit Sub
    End If
    stream.Type = 1
    stream.Open
    stream.Write http.responseBody
    stream.SaveToFile tmp, 2
    stream.Close
    If Err.Number <> 0 Then
        WriteFlag doneFlag, "err:save:" & Err.Description
        Exit Sub
    End If

    size = 0
    If fso.FileExists(tmp) Then
        Set fileObj = fso.GetFile(tmp)
        size = fileObj.Size
    End If
    If size < 1048576 Then
        WriteFlag doneFlag, "err:too_small:" & CStr(size)
        Exit Sub
    End If
    Err.Clear
    fso.MoveFile tmp, dest
    If Err.Number <> 0 Then
        WriteFlag doneFlag, "err:move:" & Err.Description
        Exit Sub
    End If
    If Not fso.FileExists(dest) Then
        WriteFlag doneFlag, "err:missing_after_move"
        Exit Sub
    End If
    WriteFlag doneFlag, "ok:" & CStr(size)
End Sub

If WScript.Arguments.Count < 4 Then WScript.Quit 1

Dim ytdlpPath, queueDir, aliveFile, myVersion, versionFile
ytdlpPath = WScript.Arguments(0)
queueDir = WScript.Arguments(1)
aliveFile = WScript.Arguments(2)
myVersion = WScript.Arguments(3)
versionFile = queueDir & "\worker.expected_version"

Sub TouchAlive()
    On Error Resume Next
    Dim f
    Set f = fso.CreateTextFile(aliveFile, True)
    f.WriteLine Now()
    f.Close
End Sub

Function VersionMismatch()
    On Error Resume Next
    VersionMismatch = False
    If fso.FileExists(versionFile) Then
        Dim f, v
        Set f = fso.OpenTextFile(versionFile, 1)
        v = f.ReadLine()
        f.Close
        If v <> myVersion Then VersionMismatch = True
    End If
End Function

Sub ProcessRequest(reqPath)
    On Error Resume Next
    Dim basePath, respPath, outPath, errPath, reqF, videoInput
    basePath = Left(reqPath, Len(reqPath) - 4)
    respPath = basePath & ".resp"
    outPath = basePath & ".out"
    errPath = basePath & ".err"
    Set reqF = fso.OpenTextFile(reqPath, 1)
    videoInput = reqF.ReadLine()
    reqF.Close
    If Len(videoInput) = 0 Then Exit Sub
    If fso.FileExists(outPath) Then fso.DeleteFile outPath, True
    If fso.FileExists(errPath) Then fso.DeleteFile errPath, True

    Dim q, ytdlpCmd, output, errOutput, safeInput
    q = Chr(34)
    safeInput = Replace(videoInput, q, "'")
    safeInput = Replace(safeInput, "%", "%%")
    ytdlpCmd = q & ytdlpPath & q & _
        " --ignore-config --no-warnings --no-playlist --socket-timeout 12 --format " & q & "bestaudio[ext=m4a]/bestaudio/best" & q & _
        " --get-id --get-title --get-url" & _
        " " & q & safeInput & q

    RunHiddenToFiles ytdlpCmd, outPath, errPath, 35000

    output = ReadAllText(outPath)
    errOutput = ReadAllText(errPath)
    If Len(output) = 0 Then output = errOutput

    Dim respF
    Set respF = fso.CreateTextFile(respPath, True)
    respF.Write output
    respF.Close
    If fso.FileExists(reqPath) Then fso.DeleteFile reqPath, True
    If fso.FileExists(outPath) Then fso.DeleteFile outPath, True
    If fso.FileExists(errPath) Then fso.DeleteFile errPath, True
End Sub

Function ReadAllText(path)
    On Error Resume Next
    ReadAllText = ""
    If Not fso.FileExists(path) Then Exit Function
    Dim f
    Set f = fso.OpenTextFile(path, 1)
    ReadAllText = f.ReadAll()
    f.Close
End Function

Sub RunHiddenToFiles(commandLine, stdoutPath, stderrPath, timeoutMs)
    On Error Resume Next
    Dim q, runnerPath, runner
    q = Chr(34)
    runnerPath = stdoutPath & ".cmd"

    Err.Clear
    Set runner = fso.CreateTextFile(runnerPath, True, False)
    If Err.Number <> 0 Then
        WriteFlag stderrPath, "ERROR: runner file could not be created: " & Err.Description
        Err.Clear
        Exit Sub
    End If
    runner.WriteLine "@echo off"
    runner.WriteLine commandLine & " > " & q & stdoutPath & q & " 2> " & q & stderrPath & q
    runner.Close

    shell.Run q & runnerPath & q, 0, True
    If Err.Number <> 0 Then
        WriteFlag stderrPath, "ERROR: runner failed: " & Err.Description
        Err.Clear
    End If
    If fso.FileExists(runnerPath) Then fso.DeleteFile runnerPath, True
End Sub

Function ProcessExists(service, pid)
    On Error Resume Next
    Dim rows
    Set rows = service.ExecQuery("Select * From Win32_Process Where ProcessId = " & CStr(pid))
    ProcessExists = (rows.Count > 0)
End Function

Sub KillProcess(service, pid)
    On Error Resume Next
    Dim rows, item
    Set rows = service.ExecQuery("Select * From Win32_Process Where ProcessId = " & CStr(pid))
    For Each item In rows
        item.Terminate()
    Next
End Sub

If Not fso.FolderExists(queueDir) Then fso.CreateFolder(queueDir)

Do While True
    If VersionMismatch() Then Exit Do
    TouchAlive

    If fso.FolderExists(queueDir) Then
        Dim folder, file
        Set folder = fso.GetFolder(queueDir)
        For Each file In folder.Files
            If LCase(Right(file.Name, 4)) = ".req" Then
                ProcessRequest file.Path
            End If
        Next
    End If

    WScript.Sleep 200
Loop

On Error Resume Next
If fso.FileExists(aliveFile) Then fso.DeleteFile aliveFile, True
WScript.Quit 0
